
// Take input from buttons, send data to Sound.c
void Piano_In(void);
