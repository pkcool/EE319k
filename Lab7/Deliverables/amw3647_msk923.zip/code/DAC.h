
void DAC_Init(void);

void DAC_Out(unsigned long packet);
