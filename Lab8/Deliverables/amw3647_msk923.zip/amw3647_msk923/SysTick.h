
#ifndef __SYSTICK_H__
#define __SYSTICK_H__

extern void SysTickIntHandler(void);
extern void SysTickInit(void);

#endif // __SYSTICK_H__
